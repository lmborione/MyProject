import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

import { DataService } from '../api/data.service';
import { Start } from '../../models/org.mob.network';


const NAMESPACE: string = 'Start';
@Injectable()
export class StartProvider {

  constructor(public dataService: DataService<Start>) { }

  public getAll(params?: any): Observable<Start[]> {
    return this.dataService.getAll(NAMESPACE);
  }

  public getSingle(id:string): Observable<Start> {
    return this.dataService.getSingle(NAMESPACE, id);
  }

  public add(itemToAdd: Start): Observable<Start> {    
    return this.dataService.add(NAMESPACE, itemToAdd);    
  }

  public update(id:string, itemToUpdate: Start): Observable<Start> {
    return this.dataService.update(NAMESPACE, id, itemToUpdate);
  }

  public delete(id: any) : Observable<Start>{
    return this.dataService.delete(NAMESPACE, id);
  }

}
