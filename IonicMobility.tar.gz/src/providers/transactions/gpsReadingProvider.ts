import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

import { DataService } from '../api/data.service';
import { GPSReading } from '../../models/org.mob.network';


const NAMESPACE: string = 'GPSReading';
@Injectable()
export class GPSReadingProvider {

  constructor(public dataService: DataService<GPSReading>) { }

  public add(itemToAdd: any): Observable<GPSReading> {    
    console.log(itemToAdd);
    return this.dataService.add(NAMESPACE, itemToAdd);    
  }
}
