import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

import { DataService } from '../api/data.service';
import { CreateMovingAsset } from '../../models/org.mob.network';


const NAMESPACE: string = 'CreateMovingAsset';
@Injectable()
export class CreateMovingAssetProvider {

  constructor(public dataService: DataService<CreateMovingAsset>) { }

  // public getAll(params?: any): Observable<CreateMovingAsset[]> {
  //   return this.dataService.getAll(NAMESPACE);
  // }

  // public getSingle(id:string): Observable<CreateMovingAsset> {
  //   return this.dataService.getSingle(NAMESPACE, id);
  // }

  public add(itemToAdd: any): Observable<CreateMovingAsset> {    
    return this.dataService.add(NAMESPACE, itemToAdd);    
  }

  // public update(id:string, itemToUpdate: CreateMovingAsset): Observable<CreateMovingAsset> {
  //   return this.dataService.update(NAMESPACE, id, itemToUpdate);
  // }

  // public delete(id: any) : Observable<CreateMovingAsset>{
  //   return this.dataService.delete(NAMESPACE, id);
  // }

}
