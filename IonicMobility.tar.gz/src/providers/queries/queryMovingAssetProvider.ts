import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

import { DataService } from '../api/data.service';
import { MovingAsset } from '../../models/org.mob.network';

/*
  Generated class for the MapProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
const NAMESPACE: string = 'queries/selectMovingAsset';

@Injectable()
export class QueryMovingAssetProvider {

  constructor(public dataService: DataService<MovingAsset>) { }

  public query(params?: any): Observable<MovingAsset[]> {
    return this.dataService.getAll(NAMESPACE);
  }
}
