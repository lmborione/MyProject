import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

import { MovingAsset } from '../../models/org.mob.network';
import { DataService } from '../api/data.service';

const NAMESPACE: string = 'MovingAsset';

@Injectable()
export class MovingAssetProvider {

  defaultItem: any = {
    "assetId": "asset 1",
    "owner": "1",
    "value": "2",
  };

  // currentItems: SampleAsset[];
  constructor(public dataService: DataService<MovingAsset>) { }

  public getAll(params?: any): Observable<MovingAsset[]> {
    return this.dataService.getAll(NAMESPACE);
  }

  public getSingle(id:string): Observable<MovingAsset> {
    return this.dataService.getSingle(NAMESPACE, id);
  }

  public add(itemToAdd: MovingAsset): Observable<MovingAsset> {    
    return this.dataService.add(NAMESPACE, itemToAdd);    
  }

  public update(id:string, itemToUpdate: MovingAsset): Observable<MovingAsset> {
    return this.dataService.update(NAMESPACE, id, itemToUpdate);
  }

  public delete(id: any) : Observable<MovingAsset>{
    return this.dataService.delete(NAMESPACE, id);
  }

}
