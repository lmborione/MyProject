import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

import { SampleAsset } from '../../models/org.mob.network';
import { DataService } from '../api/data.service';

const NAMESPACE: string = 'SampleAsset';

@Injectable()
export class SampleAssetProvider {

  defaultItem: any = {
    "assetId": "asset 1",
    "owner": "1",
    "value": "2",
  };

  // currentItems: SampleAsset[];
  constructor(public dataService: DataService<SampleAsset>) { }

  public getAll(params?: any): Observable<SampleAsset[]> {
    return this.dataService.getAll(NAMESPACE);
  }

  public getSingle(id:string): Observable<SampleAsset> {
    return this.dataService.getSingle(NAMESPACE, id);
  }

  public add(itemToAdd: SampleAsset): Observable<SampleAsset> {    
    return this.dataService.add(NAMESPACE, itemToAdd);    
  }

  public update(id:string, itemToUpdate: SampleAsset): Observable<SampleAsset> {
    return this.dataService.update(NAMESPACE, id, itemToUpdate);
  }

  public delete(id: any) : Observable<SampleAsset>{
    return this.dataService.delete(NAMESPACE, id);
  }

}
