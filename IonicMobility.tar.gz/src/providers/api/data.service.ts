import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { catchError, tap } from 'rxjs/operators';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json',
    'Accept' : 'application/json',
    'Access-Control-Allow-Origin' : '*' })
  };

@Injectable()
export class DataService<T> {

    apiUrl = window.location.origin + '/api';

    private resolveSuffix: string = '?resolve=true';
    private actionUrl: string;
    private headers: Headers;
    constructor(private http: HttpClient) {
      
        this.actionUrl = '/localapi/'; 
        this.headers = new Headers();       
        this.headers.append('Content-Type', 'application/json');
        this.headers.append('Accept', 'application/json');    
        this.headers.append('Access-Control-Allow-Origin', '*');    
    }
    
    public getAll<T>(ns: string): Observable<T[]> {
        console.log('GetAll ' + ns + ' to ' + this.actionUrl + ns);
        return this.http.get<T[]>(`${this.actionUrl}${ns}`, httpOptions).pipe(
          tap(data => console.log('data: ' + data)),
          catchError(this.handleError('getAll', []))
        );
      }

      public getSingle(ns: string, id: string): Observable<T> {
        const url = this.actionUrl + ns + '/' + id + this.resolveSuffix;
        return this.http.get<T>(url, httpOptions).pipe(
          tap(_ => console.log(`fetched single asset id=${id}`)),
          catchError(this.handleError<T>(`getasset id=${id}`))
        );
      }

      public add (ns: string, asset: T): Observable<T> {
        console.log('Entered DataService add');
        console.log('Add ' + ns);
        console.log('asset', asset);

        return this.http.post<T>(this.actionUrl + ns, asset, httpOptions).pipe(
          tap((asset: T) => console.log(`added asset w/ id=${asset}`)),
          catchError(this.handleError<T>('addAsset'))
        );
      }

   
    public update(ns: string, id: string, itemToUpdate: T): Observable<T> {
        console.log('Update ' + ns);
        console.log('what is the id?', id);
        console.log('what is the updated item?', itemToUpdate);
        console.log('what is the updated item?', JSON.stringify(itemToUpdate));

        return this.http.put(`${this.actionUrl}${ns}/${id}`, itemToUpdate, httpOptions).pipe(
            tap(_ => console.log(`updated asset id=${itemToUpdate}`)),
            catchError(this.handleError<any>('updateAsset'))
          );
    }

    public delete(ns: string, id: string): Observable<T> {
        console.log('Delete ' + ns);
        console.log('id ' + id);

        return this.http.delete<T>(this.actionUrl + ns + '/' + id, httpOptions).pipe(
            tap(_ => console.log(`deleted asset id=${id}`)),
            catchError(this.handleError<T>('deleteAsset'))
          );
    }

    public query(ns: string, paramKey: string, paramValue: string): Observable<T[]> {
      const url = this.actionUrl + ns + '?' + paramKey + '=' + paramValue;
      console.log(url);
      return this.http.get<T[]>(url, httpOptions).pipe(
        tap(data => console.log('data: ' + data)),
        catchError(this.handleError('getAll', []))
      );
    }

    private handleError<T> (operation = 'operation', result?: T) {
        return (error: any): Observable<T> => {
     
          // TODO: send the error to remote logging infrastructure
          console.error(error); // log to console instead
     
          // TODO: better job of transforming error for user consumption
          console.log(`${operation} failed: ${error.message}`);
     
          // Let the app keep running by returning an empty result.
          return of(result as T);
        };
      }
}
