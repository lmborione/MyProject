import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { catchError, tap } from 'rxjs/operators';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json',
  'Accept' : 'application/json',
  'Access-Control-Allow-Origin' : '*' })
};

@Injectable()
export class FlightService {

    private actionUrl: string;
// "proxyUrl": "https://public-api.adsbexchange.com/VirtualRadar/AircraftList.json?lat=48.86&lng=2.33&fDstL=0&fDstU=20"

    constructor(private http: HttpClient) {
         this.actionUrl = '/flightapi/VirtualRadar/AircraftList.json?lat=48.86&lng=2.33&fDstL=0&fDstU=20';        
    }
    
    public getAll(): Observable<any> {
      console.log('GetAll ' + this.actionUrl);
      return this.http.get<any>(`${this.actionUrl}`, httpOptions).pipe(
        tap(data => console.log('data: ' + data)),
        catchError(this.handleError('getAll', []))
      );
    }

    // public get(): any {
    //     console.log('Get ' + this.actionUrl);
    //     this.http.get<any[]>(`${this.actionUrl}`, httpOptions)
    //     .subscribe(flightJson => {
    //       console.log(flightJson);          
    //       flightJson.map(flight => {
    //         console.log(flight);
            
    //       }          
    //       )          
    //     }
    //     );
    //     return;
    //   }

    private handleError<T> (operation = 'operation', result?: T) {
        return (error: any): Observable<T> => {
     
          // TODO: send the error to remote logging infrastructure
          console.error(error); // log to console instead
     
          // TODO: better job of transforming error for user consumption
          console.log(`${operation} failed: ${error.message}`);
     
          // Let the app keep running by returning an empty result.
          return of(result as T);
        };
      }
}
