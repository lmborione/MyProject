import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

import { Owner } from '../../models/org.mob.network';
import { DataService } from '../api/data.service';

const NAMESPACE: string = 'Owner';

@Injectable()
export class OwnerProvider {

  defaultItem: any = {
    "participantId": "test",
    "firstName": "test",
    "lastName": "test",
  };

  constructor(public dataService: DataService<Owner>) { }

  public getAll(params?: any): Observable<Owner[]> {
    return this.dataService.getAll(NAMESPACE);
  }

  public getSingle(id:string): Observable<Owner> {
    return this.dataService.getSingle(NAMESPACE, id);
  }

  public add(itemToAdd: Owner): Observable<Owner> {    
    return this.dataService.add(NAMESPACE, itemToAdd);    
  }

  public update(id:string, itemToUpdate: Owner): Observable<Owner> {
    return this.dataService.update(NAMESPACE, id, itemToUpdate);
  }

  public delete(id: any) : Observable<Owner>{
    return this.dataService.delete(NAMESPACE, id);
  }

}
