import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

import { SampleParticipant } from '../../models/org.mob.network';
import { DataService } from '../api/data.service';

const NAMESPACE: string = 'SampleParticipant';

@Injectable()
export class SampleParticipantProvider {

  defaultItem: any = {
    "participantId": "test",
    "firstName": "test",
    "lastName": "test",
  };

  constructor(public dataService: DataService<SampleParticipant>) { }

  public getAll(params?: any): Observable<SampleParticipant[]> {
    return this.dataService.getAll(NAMESPACE);
  }

  public getSingle(id:string): Observable<SampleParticipant> {
    return this.dataService.getSingle(NAMESPACE, id);
  }

  public add(itemToAdd: SampleParticipant): Observable<SampleParticipant> {    
    return this.dataService.add(NAMESPACE, itemToAdd);    
  }

  public update(id:string, itemToUpdate: SampleParticipant): Observable<SampleParticipant> {
    return this.dataService.update(NAMESPACE, id, itemToUpdate);
  }

  public delete(id: any) : Observable<SampleParticipant>{
    return this.dataService.delete(NAMESPACE, id);
  }

}
