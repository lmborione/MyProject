import { Injectable } from '@angular/core';
import { Observable } from "rxjs";

import { Borrower } from '../../models/org.mob.network';
import { DataService } from '../api/data.service';

const NAMESPACE: string = 'Borrower';

@Injectable()
export class BorrowerProvider {

  defaultItem: any = {
    "participantId": "test",
    "firstName": "test",
    "lastName": "test",
  };

  constructor(public dataService: DataService<Borrower>) { }

  public getAll(params?: any): Observable<Borrower[]> {
    return this.dataService.getAll(NAMESPACE);
  }

  public getSingle(id:string): Observable<Borrower> {
    return this.dataService.getSingle(NAMESPACE, id);
  }

  public add(itemToAdd: Borrower): Observable<Borrower> {    
    return this.dataService.add(NAMESPACE, itemToAdd);    
  }

  public update(id:string, itemToUpdate: Borrower): Observable<Borrower> {
    return this.dataService.update(NAMESPACE, id, itemToUpdate);
  }

  public delete(id: any) : Observable<Borrower>{
    return this.dataService.delete(NAMESPACE, id);
  }

}
