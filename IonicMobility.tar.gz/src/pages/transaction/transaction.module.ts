import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TransactionPage } from './transaction';

import { TranslateModule } from '@ngx-translate/core';


import { PipesModule } from '../../pipes/pipes.module';

@NgModule({
  declarations: [
    TransactionPage,
  ],
  imports: [
    IonicPageModule.forChild(TransactionPage),
    TranslateModule.forChild(),
    PipesModule
  ],
  exports: [
    TransactionPage
  ]
})
export class TransactionPageModule {}
