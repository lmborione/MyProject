import { Component } from '@angular/core';
import { IonicPage, ModalController, NavController } from 'ionic-angular';
import { Observable } from "rxjs";
import { Geolocation } from '@ionic-native/geolocation';

import { OwnerProvider } from '../../providers';
import { BorrowerProvider } from '../../providers';
import { MovingAsset } from '../../models/org.mob.network';
import { MovingAssetProvider } from '../../providers';
import { CreateMovingAssetProvider } from '../../providers';
import { GPSReadingProvider } from '../../providers';
import { FlightService } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-list-master',
  templateUrl: 'list-master.html'
})
export class ListMasterPage {
  currentItems: Observable<MovingAsset[]>;
  flightItems: any;
  i = 0;

  constructor(public navCtrl: NavController,
    private geolocation: Geolocation,
    public movingAssetProvider: MovingAssetProvider,
    public createMovingAssetProvider: CreateMovingAssetProvider,
    public gpsReadingProvider: GPSReadingProvider,
    public ownerProvider: OwnerProvider,
    public borrowerProvider: BorrowerProvider,
    public flightService: FlightService,
    public modalCtrl: ModalController) {
  }
  
  registerMyLocation() {
    // this.geolocation.getCurrentPosition().then((resp) => {
    //   console.log(resp.coords.latitude + '-' + resp.coords.longitude);

    // }).catch((error) => {
    //   console.log('Error getting location', error);
    // });

    let watch = this.geolocation.watchPosition();
    watch.subscribe((data) => {
      console.log(this.i);
      this.i++;
      console.log(data.coords.latitude + '-' + data.coords.longitude);
      // data can be a set of coordinates, or an error (if an error occurred).
      // data.coords.latitude
      // data.coords.longitude
    });
  }

  getflight() {

    this.flightService.getAll().subscribe((flightList) => {
      console.log(flightList.acList);

      flightList.acList.forEach(flight => {
        console.log(flight);

        var exist = false;
        var detectedAssetId = flight.CNum + flight.Call;
        this.movingAssetProvider.getSingle(detectedAssetId)
          .subscribe(movAsset => {
            if (movAsset != null && movAsset.lastCoordinate != flight.Long + "," + flight.Lat) {
              var gpsLocation =
              {
                '$class': 'org.mob.network.GPSReading',
                'movingAsset': 'org.mob.network.MovingAsset#' + detectedAssetId,
                Coordinates: flight.Long + "," + flight.Lat
              };
              this.gpsReadingProvider.add(gpsLocation)
                .subscribe(req => {
                  console.log(req);
                });
            }
          });

        if (!exist) {
          var newitem =
          {
            '$class': 'org.mob.network.CreateMovingAsset',
            'assetId': flight.CNum + flight.Call,
            'lastBorrower': 'org.mob.network.Borrower#lmborione@gmail.com',
            'owner': 'org.mob.network.Owner#lmborione@gmail.com',
            'value': '0',
            'lastCoordinate': flight.Long + "," + flight.Lat
          };
          console.log(newitem);
          this.createMovingAssetProvider.add(newitem)
            .subscribe(req => {
              console.log(req);
            });
        }
      });
    }
    );
  }

  refresh() {
    this.currentItems = this.movingAssetProvider.getAll();
  }
  /**
   * The view loaded, let's query our items for the list
   */
  ionViewDidLoad() {
    this.refresh();
  }

  /**
   * Prompt the user to add a new item. This shows our ItemCreatePage in a
   * modal and then adds the new item to our data source if the user created one.
   */
  addItem() {

    let addModal = this.modalCtrl.create('ItemCreatePage');
    addModal.onDidDismiss(item => {
      if (item) {
        item.lastBorrower = 'org.mob.network.Borrower#' + item.lastBorrower;
        item.owner = 'org.mob.network.Owner#' + item.owner;

        this.createMovingAssetProvider.add(item)
          .subscribe(req => {
            console.log(req);
          });

      }
    })
    addModal.present();


  }

  /**
   * Delete an item from the list of items.
   */
  deleteItem(item) {
    this.movingAssetProvider.delete(item.assetId)
      .subscribe(asset => {
        this.refresh();
      });
  }

  /**
   * Navigate to the detail page for this item.
   */
  openItem(item: MovingAsset) {
    this.navCtrl.push('ItemDetailPage', {
      item: item
    });
  }


}
