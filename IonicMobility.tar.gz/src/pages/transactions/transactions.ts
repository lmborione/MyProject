import { Component } from '@angular/core';
import { IonicPage, NavController, AlertController } from 'ionic-angular';

import { Start, UndoStart } from '../../models/org.mob.network';
import { StartProvider, UndoStartProvider } from "../../providers";

@IonicPage()
@Component({
  selector: 'page-transactions',
  templateUrl: 'transactions.html'
})
export class TransactionsPage {

  allTransactions: string[];

  constructor(public navCtrl: NavController, private alertCtrl: AlertController,
    public startTransactionProvider: StartProvider,
    public undostartTransactionProvider: UndoStartProvider) {
  }

  ionViewDidLoad() {
    this.allTransactions = ["Start", "UndoStart"];
  }

  /**
   * Prompt the user to add a new item. This shows our ItemCreatePage in a
   * modal and then adds the new item to our data source if the user created one.
   */
  doStartTransaction() {
    this.confirmTransaction().then(res => {
      if (res) {
        let trans = new Start();
        this.startTransactionProvider.add(trans)
          .subscribe(req => {
            console.log(req);
          });
      }
    });
  }

  /**
   * Prompt the user to add a new item. This shows our ItemCreatePage in a
   * modal and then adds the new item to our data source if the user created one.
   */
  doUndoStartTransaction() {
    this.confirmTransaction().then(res => {
      if (res) {
        let trans = new UndoStart();
        this.undostartTransactionProvider.add(trans)
          .subscribe(req => {
            console.log(req);
          });
      }
    });
  }

  postTransaction(name: string) {
    console.log(name);

    if (name == "Start") {
      this.doStartTransaction();
    }
    else if (name == "UndoStart") {
      this.doUndoStartTransaction();
    }
  }

  confirmTransaction(): Promise<boolean> {
    return new Promise((resolve, reject) => {

      let alert = this.alertCtrl.create({
        title: 'Transaction',
        message: 'Do you want to send the transaction to the blockchain?',
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
            handler: () => {
              alert.dismiss().then(() => { resolve(false); });
              return false;
            }
          },
          {
            text: 'OK',
            handler: () => {
              alert.dismiss().then(() => { resolve(true); });
              return false;
            }
          }]
      });

      alert.present();

    });
  }
}
