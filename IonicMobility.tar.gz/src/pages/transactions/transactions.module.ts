import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IonicPageModule } from 'ionic-angular';

import { TransactionsPage } from './transactions';

@NgModule({
  declarations: [
    TransactionsPage,
  ],
  imports: [
    IonicPageModule.forChild(TransactionsPage),
    TranslateModule.forChild()
  ],
  exports: [
    TransactionsPage
  ]
})
export class TransactionsPageModule { }
