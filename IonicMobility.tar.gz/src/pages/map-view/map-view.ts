import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { QueryMovingAssetProvider } from "../../providers";
import mapboxgl from 'mapbox-gl/dist/mapbox-gl.js'


const mapBoxToken = 'pk.eyJ1IjoibG1ib3Jpb25lIiwiYSI6ImNqZzJpbmd4MDB6dmoycXFwYnpjb3l4MnQifQ.IXPRNhTKsQFTeXsmf0vbrA';
@IonicPage()
@Component({
  selector: 'page-map-view',
  templateUrl: 'map-view.html',
})
export class MapViewPage {
  private map: mapboxgl.Map;
  private markers;
  public watch: any;
  public showAll: boolean = true;
  private geoJson: any;

  constructor(public navCtrl: NavController, public navParams: NavParams,
    public queryLocationProvider: QueryMovingAssetProvider
  ) {

  }

  ionViewDidEnter() {

    this.queryLocationProvider.query().subscribe(queryResult => {

      this.geoJson = [];
      queryResult.forEach(feature => {

        var coord = feature.lastCoordinate;
        var val = coord.split(',');

        this.geoJson.push({
          type: 'Feature',
          properties: {
            title: '<strong>' + feature.assetId + '</strong><p>',
            description: feature.lastBorrower,
          },
          geometry: {
            type: 'Point',
            coordinates: [
              parseFloat(val[0]),
              parseFloat(val[1]),
            ]
          }
        }, );
      });

      console.log(this.geoJson);
      mapboxgl.accessToken = mapBoxToken;
      this.map = new mapboxgl.Map({
        style: 'mapbox://styles/mapbox/light-v9',
        center: [2.3394, 48.8613],
        zoom: 9,
        // pitch: 0,
        container: 'map'
      });
      this.executemap(this.map, this.geoJson);

    });
  }

  showMapLayer(map, geoJson, showAll, markers) {


  }

  changeClusterVisibility() {
    if (this.showAll) {
      this.markers.forEach(marker => {
        marker.remove();
      });

      this.map.addLayer({
        id: "clusters",
        type: "circle",
        source: "movAssets",
        filter: ["has", "point_count"],
        paint: {
          "circle-color": [
            "step",
            ["get", "point_count"],
            "#51bbd6",
            100,
            "#f1f075",
            750,
            "#f28cb1"
          ],
          "circle-radius": [
            "step",
            ["get", "point_count"],
            20,
            100,
            30,
            750,
            40
          ]
        }
      });

      this.map.addLayer({
        id: "cluster-count",
        type: "symbol",
        source: "movAssets",
        filter: ["has", "point_count"],
        layout: {
          "text-field": "{point_count_abbreviated}",
          "text-font": ["DIN Offc Pro Medium", "Arial Unicode MS Bold"],
          "text-size": 12
        }
      });

      this.map.addLayer({
        id: "unclustered-point",
        type: "symbol",
        source: "movAssets",
        filter: ["has", "point_count"],
        layout: {
          "icon-image": "marker-circle-green",
          "text-field": "{point_count_abbreviated}",
          "text-font": ["DIN Offc Pro Medium", "Arial Unicode MS Bold"],
          "text-size": 9,
          "icon-allow-overlap": true,
          "icon-offset": [0, -12]
        }
        // paint: {
        //   "circle-color": "#11b4da",
        //   "circle-radius": 4,
        //   "circle-stroke-width": 1,
        //   "circle-stroke-color": "#fff"
        // }
      });

    }
    else {
      this.map.removeLayer("clusters");
      this.map.removeLayer("cluster-count");
      //this.map.removeLayer("unclustered-point");

      this.markers = [];

      this.geoJson.forEach(geoJsonElement => {

        // create a HTML element for each feature
        var el = document.createElement('div');
        el.className = 'marker';

        // // make a marker for each feature and add to the map
        // new mapboxgl.Marker(el)
        //   .setLngLat(marker.geometry.coordinates)
        //   .addTo(map);

        this.markers.push(
          new mapboxgl.Marker(el)
            .setLngLat(geoJsonElement.geometry.coordinates)
            .setPopup(new mapboxgl.Popup({ offset: 25 }) // add popups
              .setHTML('<h3>' + geoJsonElement.properties.title + '</h3><p>' + geoJsonElement.properties.description + '</p>'))
            .addTo(this.map));

      });
    }
  }

  executemap(map, geoJson) {

    map.on('load', function () {
      console.log(geoJson);
      map.addSource('movAssets', {
        "type": "geojson",
        "data": {
          "type": "FeatureCollection",
          "features": geoJson
        },
        cluster: true,
        clusterRadius: 50
      });

      map.addLayer({
        id: "clusters",
        type: "circle",
        source: "movAssets",
        filter: ["has", "point_count"],
        paint: {
          "circle-color": [
            "step",
            ["get", "point_count"],
            "#51bbd6",
            100,
            "#f1f075",
            750,
            "#f28cb1"
          ],
          "circle-radius": [
            "step",
            ["get", "point_count"],
            20,
            100,
            30,
            750,
            40
          ]
        }
      });

      map.addLayer({
        id: "cluster-count",
        type: "symbol",
        source: "movAssets",
        filter: ["has", "point_count"],
        layout: {
          "text-field": "{point_count_abbreviated}",
          "text-font": ["DIN Offc Pro Medium", "Arial Unicode MS Bold"],
          "text-size": 12
        }
      });
      // map.loadImage('https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/Cat_silhouette.svg/400px-Cat_silhouette.svg.png', function (error, image) {
        // map.loadImage('http://www.ennovativecapital.com/wp-content/uploads/2016/01/Location-512.png', function(error, image) {
        //   console.log("test1");
        // if (error) throw error;
        // map.addImage('mymarker', image);
        // console.log("test2");        
        map.addLayer({
          id: "unclustered-point",
          type: "symbol",
          source: "movAssets",
          filter: ["!has", "point_count"],
          layout: {
            "icon-image": "marker-11",
            "icon-size": 2,
            
            "icon-allow-overlap": false,
            
            // "circle-color": "#11b4da",
            // "circle-radius": 4,
            // "circle-stroke-width": 1,
            // "circle-stroke-color": "#fff"
          }
        });
      // });
        // this.map.addLayer({
        //   id: "unclustered-point",
        //   type: "symbol",
        //   source: "movAssets",
        //   filter: ["has", "point_count"],
        //   layout: {
        //     "icon-image": "marker-circle-green",
        //     "text-field": "{point_count_abbreviated}",
        //     "text-font": ["DIN Offc Pro Medium", "Arial Unicode MS Bold"],
        //     "text-size": 9,
        //     "icon-allow-overlap": true,
        //     "icon-offset": [0, -12]
        // }

        // var myLayer = map.addLayer({
        //   "id": "assetLocation",
        //   "source": "movAssets",
        //   "filter": ["==", "$type", "Point"],
        //   'type': 'circle',
        //   'paint': {
        //     'circle-radius': 1,
        //     'circle-color': '#000000'
        //   },
        //   "cluster": "true",
        //   "clusterMaxZoom": "14",
        //   "clusterRadius": "30"
        // });

      
    });



    // Add click handlers
    map.on('click', (e) => {
      const features = map.queryRenderedFeatures(e.point, { layers: ['unclustered-point'] })
      if (!features.length) { return }
      console.log(e);
      
      var coordinates = e.lngLat;
        var description = features[0].properties.description;

        // Ensure that if the map is zoomed out such that multiple
        // copies of the feature are visible, the popup appears
        // over the copy being pointed to.
        // while (Math.abs(e.lngLat.lng - coordinates[0]) > 180) {
        //     coordinates[0] += e.lngLat.lng > coordinates[0] ? 360 : -360;
        // }

        new mapboxgl.Popup()
            .setLngLat(coordinates)
            .setHTML(description)
            .addTo(map);

      // Do what you're gonna do
    });


    // Change pointer style on hover
    map.on('mousemove', function (e) {
      var features = map.queryRenderedFeatures(e.point, { layers: ['unclustered-point'] });
      map.getCanvas().style.cursor = features.length ? 'pointer' : '';
    });


  }


}
