import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Observable } from "rxjs";

import { MovingAsset } from '../../models/org.mob.network';
import { GPSReading } from '../../models/org.mob.network';
import { QueryLocationForAssetProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-item-detail',
  templateUrl: 'item-detail.html'
})
export class ItemDetailPage {
  item: MovingAsset;
  gpsReadings: Observable<GPSReading[]>;
  showCoord : boolean;

  constructor(public navCtrl: NavController, 
    navParams: NavParams,
    public queryLoc: QueryLocationForAssetProvider
  ) {
    this.item = navParams.get('item');
    this.showCoord = false;
  }

  
  toggleCoordinates = function() {
    this.showCoord = !this.showCoord;  
  }; 

    /**
   * The view loaded, let's query our items for the list
   */
  ionViewDidLoad() {
    this.gpsReadings = this.queryLoc.query(this.item.assetId);

  }
}
