import { Component, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Observable } from "rxjs";
import { IonicPage, NavController, ViewController } from 'ionic-angular';

import { Owner } from "../../models/org.mob.network";
import { Borrower } from "../../models/org.mob.network";
import { OwnerProvider } from '../../providers';
import { BorrowerProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-item-create',
  templateUrl: 'item-create.html'
})
export class ItemCreatePage {
selectedOwner: Owner;
selectedBorrower: Borrower;

  owners: Observable<Owner[]>;
  borrowers: Observable<Borrower[]>;

  isReadyToSave: boolean;

  item: any;

  form: FormGroup;

  constructor(public navCtrl: NavController, public viewCtrl: ViewController,
    formBuilder: FormBuilder, private _cdr: ChangeDetectorRef,
    private borrowerProvider: BorrowerProvider,
      private ownerProvider: OwnerProvider) {

        
    this.form = formBuilder.group({
      assetId: ['Test'],
      owner: [''],
      value: ['1'],
      lastBorrower: [''],
      lastCoordinate: ['0'],

    });

    // Watch the form for changes, and
    this.form.valueChanges.subscribe((v) => {
      this.isReadyToSave = this.form.valid;
    });
  }

  onOwnerChange(): void {
    //let owner = this.form.get('owner').value;
    this._cdr.detectChanges();
  }

  onBorrowerChange(): void {
    //let owner = this.form.get('owner').value;
    this._cdr.detectChanges();
  }

  ionViewDidLoad() {
    
    this.owners = this.ownerProvider.getAll();
    this.borrowers = this.borrowerProvider.getAll();


  }

  /**
   * The user cancelled, so we dismiss without sending data back.
   */
  cancel() {
    this.viewCtrl.dismiss();
  }

  /**
   * The user is done and wants to create the item, so return it
   * back to the presenter.
   */
  done() {
    if (!this.form.valid) { return; }
    //this.form.controls['owner'].setValue('org.mob.network.SampleParticipant#' + this.form.get('owner'));
    this.viewCtrl.dismiss(this.form.value);
  }
}
