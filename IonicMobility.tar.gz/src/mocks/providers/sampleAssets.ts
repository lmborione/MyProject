import { Injectable } from '@angular/core';

import { SampleAsset } from '../../models/org.mob.network';

@Injectable()
export class SampleAssets {
  items: SampleAsset[] = [];

  defaultItem: any = {
    "assetId": "asset 1",
    "owner": "1",
    "value": "2",
  };


  constructor() {
    let items = [
      {
        "assetId": "asset 1",
        "owner": "1",
        "value": "2",
      },
      {
        "assetId": "asset 2",
        "owner": "1",
        "value": "2",
      }
    ];

    for (let item of items) {
      this.items.push(new SampleAsset(item));
    }
  }

  query(params?: any) {
    if (!params) {
      console.log('query items' + params);
      return this.items;
    }

    return this.items.filter((item) => {
      for (let key in params) {
        let field = item[key];
        if (typeof field == 'string' && field.toLowerCase().indexOf(params[key].toLowerCase()) >= 0) {
          return item;
        } else if (field == params[key]) {
          return item;
        }
      }
      return null;
    });
  }

  add(item: SampleAsset) {
    this.items.push(item);
  }

  delete(item: SampleAsset) {
    this.items.splice(this.items.indexOf(item), 1);
  }
}
