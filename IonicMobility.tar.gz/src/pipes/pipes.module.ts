import { NgModule } from '@angular/core';
import { ComposerAssetPipe } from './composer-asset/composer-asset';
import { ComposerSampleParticipantPipe } from './composer-sample-participant/composer-sample-participant';
@NgModule({
	declarations: [ComposerAssetPipe,
    ComposerSampleParticipantPipe],
	imports: [],
	exports: [ComposerAssetPipe,
    ComposerSampleParticipantPipe]
})
export class PipesModule {}
