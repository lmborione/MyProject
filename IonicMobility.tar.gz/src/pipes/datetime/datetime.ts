import { Pipe, PipeTransform } from '@angular/core';
import { Constants } from "../../models/org.mob.network";
/**
 * Generated class for the ComposerSampleParticipantPipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'datetime',
})
export class DateTimePipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
  transform(value: string, ...args) {
    console.log(value);
    console.log(Constants.NS + '.SampleParticipant#');
    return Constants.NS + '.SampleParticipant#' + value.toLowerCase();
  }
}
