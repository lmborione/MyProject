import {Asset} from './org.hyperledger.composer.system';
import {Participant} from './org.hyperledger.composer.system';
import {Transaction} from './org.hyperledger.composer.system';
import {Event} from './org.hyperledger.composer.system';

export class Constants {
    public static get NS(): string { return "org.mob.network"; };
  }

// export namespace org.mob.network{
   export class SampleParticipant extends Participant {
      participantId: string;
      firstName: string;
      lastName: string;
   }
   export class SampleAsset extends Asset {
      assetId: string;
      owner: SampleParticipant;
      value: string;
   }
   export class SampleTransaction extends Transaction {
      asset: SampleAsset;
      newValue: string;
   }
   export class SampleEvent extends Event {
      asset: SampleAsset;
      oldValue: string;
      newValue: string;
   }
   export class Contract extends Asset {
      contractId: string;
      owner: Owner;
      borrower: Borrower;
      movingAsset: MovingAsset;
      value: string;
      date: string;
   }
   export class MovingAsset extends SampleAsset {
      lastBorrower: Borrower;
      borrowers: Borrower[];
      lastCoordinate: string;
      coordinates: string[];
   }
   export class Owner extends SampleParticipant {
   }
   export class Borrower extends SampleParticipant {
   }
   export class GPSReadingEvent extends Event {
      movingAsset: MovingAsset;
      oldCoordinates: string;
      newCoordinates: string;
   }
   export class CreateContract extends Transaction {
      owner: Owner;
      borrower: Borrower;
      movingAsset: MovingAsset;
      newValue: string;
   }
   export class CreateMovingAsset extends Transaction {
    assetId: string;
    owner: Owner;
    lastBorrower: Borrower;
    lastCoordinate: string;
    value: string;
 }
   export class GPSReading extends SampleTransaction {
      movingAsset: MovingAsset;
      Coordinates: string;
   }
   export class Start extends Transaction {
   }
   export class UndoStart extends Transaction {
  }
// }
