cd ~/fabric-dev-servers/mobility-network
read -p "Please enter version :" varversion
file="mobility-network@$varversion.bna"
composer archive create -t dir -n .
echo $file
if [ -e "$file" ]; then
    composer network install --card PeerAdmin@hlfv1 --archiveFile $file
    composer network upgrade -c PeerAdmin@hlfv1 -n mobility-network -V $varversion
else 
 echo "Edit Package.json"
fi 
