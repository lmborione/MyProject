cd ~/fabric-tools
./startFabric.sh
./createPeerAdminCard.sh

cd geoloc-network
composer archive create -t dir -n .
composer network install --card PeerAdmin@hlfv1 --archiveFile mobility-network@0.0.1.bna

composer network start --networkName mobility-network --networkVersion 0.0.1 --networkAdmin admin --networkAdminEnrollSecret adminpw --card PeerAdmin@hlfv1 --file networkadmin.card

composer card import --file networkadmin.card
composer network ping --card admin@mobility-network

composer-rest-server -c admin@mobility-network -n never -w true

docker rmi $(docker images dev-* -q)


yo hyperledger-composer:angular

composer archive create -t dir -n .
composer network install --card PeerAdmin@hlfv1 --archiveFile geoloc-network@0.0.2.bna
composer network upgrade -c PeerAdmin@hlfv1 --networkName geoloc-network --networkVersion 0.0.3

cd ~/fabric-tools
./stopFabric.sh
./teardownFabric.sh
rm -rf ~/.composer

docker kill $(docker ps -q)
docker rm $(docker ps -aq)
docker rmi $(docker images dev-* -q)

composer card export -c admin@geoloc-network -f bnaadmin-shared.card


composer network list -c admin@geoloc-network


docker logs -f dev-peer0.org1.example.com-mobility-network-0.19.4 2>&1 | grep @debug

composer transaction submit -c admin@mobility-network -d '{"$class":"org.mob.network.Start"}'

composer transaction submit -c admin@geoloc-network -d '{"$class":"org.acme.geolocnetwork.GPSReading", 
"movingAsset":"org.acme.geolocnetwork.MovingAsset#MOVASSET_001", "coordinate":"2.3894, 48.8813"}'

composer archive list -a geoloc-network@0.0.1.bna
composer network list -c admin@mobility-network
composer network list -c admin@geoloc-network
composer network list -c PeerAdmin@hlfv1

composer transaction submit -c admin@mobility-network -d'{"$class":"org.mob.network.GPSReading", "movingAsset":"org.mob.network.MovingAsset#MOVASSET_001", "Coordinates":"2.3694, 48.8713"}'

{
  "lastBorrower": "org.mob.network.Borrower#lmborione@gmail.com",
  "lastCoordinate": "0, 0",
  "assetId": "MOVASSET_002",
  "owner": "org.mob.network.Owner#dpatureaux@gmail.com",
  "value": "1"
}


{
  "$class": "org.acme.geolocnetwork.MovingAsset",
  "borrower": "org.acme.geolocnetwork.Borrower#lmborione@gmail.com",
  "lastCoordinate": "0, 0",
  "assetId": "MOVASSET_002",
  "owner": "org.acme.geolocnetwork.Borrower#dpatureaux@gmail.com",
  "value": "1"
}
