cd ~/fabric-dev-servers
./stopFabric.sh
./teardownFabric.sh
./teardownAllDocker.sh
rm -rf ~/.composer

docker kill $(docker ps -q)
docker rm $(docker ps -aq)
docker rmi $(docker images dev-* -q)