var exitTime = 10;
var texteDuButtonAbonner = "S'abonner";
var tempsDePauseEntreClick = 10


var loop = 0;
var Height=document.documentElement.scrollHeight;
var i=0;
var done = false;


function doFollow() {



// You need to wait 60 seconds after every unfollow, otherwise you will
// be blocked temporary by the Instagram API and you'll see a 403 error in the network !
var currentTime = 0;
var step = tempsDePauseEntreClick * 1000;

var followButtons = document.getElementsByClassName("oF4XW sqdOP  L3NKy      ");
var totalfollowButtons = followButtons.length;
console.log(totalfollowButtons);
if(!totalfollowButtons){
	alert("Error: no Following buttons found, maybe change the text of the button?");
}

var index = 0;
Array.prototype.forEach.call(followButtons, followButton => {

	if(followButton.innerHTML == texteDuButtonAbonner) {
		console.log(followButton.innerHTML);
		setTimeout(function(){
			(function(i){
				console.log(`following ${i} of ${totalfollowButtons}`);
				index++;
				if(i == totalfollowButtons){
					console.log("Script finished succesfully !");
				}

				followButton.click();

				// Important: recently, a confirmation dialog was added when  you click
				// on unfollow, so simply click the confirmation button as well to unfollow the user
				setTimeout(function(){
					
				}, 100);
			})(index + 1);
		}, currentTime);
	}
	currentTime += step;
});
}

function myTimer() {
	if(!done) {
		console.log(done);
		if(loop < exitTime / 2){    
			console.log(loop);
			window.scrollTo(0,i);
			i = i +Height;
			loop++;
		} else {
			done = true;			
		}
	} else {
		console.log("here");
		doFollow();
		clearInterval(myVar);
	}
}

var myVar = setInterval(myTimer, 2000);

