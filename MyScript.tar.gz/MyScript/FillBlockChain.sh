composer participant add -c admin@geoloc-network -d  '{"$class":"org.acme.geolocnetwork.AssetBorrower","participantId":"lmborione@gmail.com","firstName":"Louis","lastName":"Borione"}'

composer participant add -c admin@geoloc-network -d  '{"$class":"org.acme.geolocnetwork.AssetBorrower","participantId":"dpatureaux@gmail.com","firstName":"Damien","lastName":"Patureaux"}'

composer asset add -c admin@geoloc-network -d  '{"$class":"org.acme.geolocnetwork.AssetBorrower","participantId":"dpatureaux@gmail.com","firstName":"Damien","lastName":"Patureaux"}'

composer transaction submit --card admin@geoloc-network -d '{ "$class": "org.acme.geolocnetwork.SampleAsset", "assetId":"asset1", "owner":"resource:org.acme.geolocnetwork.AssetBorrower✔dpatureaux@gmail.com", "value":"1"}'



