cd ~/fabric-dev-servers
./startFabric.sh
./createPeerAdminCard.sh

cd ~/fabric-dev-servers/mobility-network
composer archive create -t dir -n .
composer network install --card PeerAdmin@hlfv1 --archiveFile mobility-network@0.0.21.bna

composer network start --networkName mobility-network --networkVersion 0.0.21 --networkAdmin admin --networkAdminEnrollSecret adminpw --card PeerAdmin@hlfv1 --file networkadmin.card

composer card import --file networkadmin.card
composer network ping --card admin@mobility-network

