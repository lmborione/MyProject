npm uninstall -g composer-cli composer-rest-server generator-hyperledger-composer
npm install -g composer-cli composer-rest-server generator-hyperledger-composer
npm uninstall -g composer-playground
npm install -g composer-playground
